﻿using Astronomy.Pages;
using Xamarin.Forms;
using System;

namespace Astronomy
{
    public partial class AstronomyMasterPage : ContentPage
    {
        public AstronomyMasterPage()
        {
            InitializeComponent();
        }
    }
}