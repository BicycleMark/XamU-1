﻿namespace Astronomy
{
    public enum PageType
    {
        Sunrise,
        MoonPhase,
        Earth,
        Moon,
        Sun,
        About,
    }
}