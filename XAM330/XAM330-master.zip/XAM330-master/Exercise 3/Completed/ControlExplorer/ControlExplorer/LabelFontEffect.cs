﻿using Xamarin.Forms;

namespace ControlExplorer
{
    class LabelFontEffect : RoutingEffect
    {
        public LabelFontEffect() : base("Xamarin.CustomFontEffect")
        {
        }
    }
}
