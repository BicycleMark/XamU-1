using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace Mailbox
{
	partial class TableViewController : UITableViewController
	{
		public TableViewController (IntPtr handle) : base (handle)
		{
		}
	}
}
